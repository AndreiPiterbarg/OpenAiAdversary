# Generated adversary diagnostic pilot

Prompted proposer; no trained, protected, or confirmed mode claim.

Executions: 5; measured: 5; attributable unknown: 0; visibly changed: 5.

| Task | Cell | Attributable / executions | Passes | Five-run task failure |
|---|---:|---:|---:|---|
| factoryboy__factory_boy-1067 | 3 | 5 / 5 | 5 | False |

Descriptive contrasts use five-execution failure fractions, not population estimates.
Unrealized active conditions and censored executions remain unknown in the denominator.
Additive excess subtracts clipped A + B - control. No confidence intervals.

| Task | A − control | B − control | All-on − control | Additive excess |
|---|---:|---:|---:|---:|
| factoryboy__factory_boy-1067 | unknown | unknown | unknown | unknown |
