"""History-derived proposal inputs."""
