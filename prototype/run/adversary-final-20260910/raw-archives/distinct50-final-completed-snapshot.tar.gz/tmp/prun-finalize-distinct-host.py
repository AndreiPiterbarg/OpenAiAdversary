import pathlib,json,sys,os,dataclasses,time
os.environ.update(OPENBLAS_NUM_THREADS='1',OMP_NUM_THREADS='1')
sys.path.insert(0,'/tmp/prun-adversary-final-20260910/experiment-code-v8')
from domains.swe_agents.environment.interactive_runtime import InteractiveRuntime,HostRuntimePin
from domains.swe_agents.environment.guarded_session import install_host_guard
R=pathlib.Path('/tmp/prun-distinct-host-prep-v3')
for loop in range(20):
 for root in R.iterdir():
  p=root/'compatibility-exact.json'
  if not p.exists():continue
  check=json.loads(p.read_text())
  if check.get('external_receipt_access_denied'):continue
  session=None
  try:
   d=json.loads((root/'host-runtime-pin.json').read_text());d={k:v for k,v in d.items() if k in {f.name for f in dataclasses.fields(HostRuntimePin)}}
   for k in ['repository','venv','system_python']:d[k]=pathlib.Path(d[k])
   hp=HostRuntimePin(**d);runtime=InteractiveRuntime(hp);session=runtime.start_guarded(lambda raw,h:install_host_guard(raw,h,host_nproc=1536));receipts=[]
   for path in ['/tmp/prun-adversary-final-20260910/distinct50-final/registration.json',str(root/'original-pin.json'),'/tmp/prun-host-prep-20260910/factoryboy__factory_boy-1067-historyfree-v1/original-pin.json']:
    assert pathlib.Path(path).is_file()
    code,out,err=session.exec('cat '+path,10);assert code!=0 and not out and 'Permission denied' in err,(code,out,err);receipts.append({'path':path,'exit':code,'stderr':err,'stdout':out})
   assert session.exec('git rev-list --all --count',10)[1].strip()=='1'
   code,out,err=session.exec('git fsck --unreachable --no-reflogs',10);assert code==0 and not out.strip()
   runtime.verify();session.stop();session=None
   (root/'external-receipt-access-check.json').write_text(json.dumps({'all_denied':True,'receipts':receipts,'single_commit_no_unreachable':True},indent=2));check['external_receipt_access_denied']=True;(root/'compatibility-before-denial-probe.json').write_bytes(p.read_bytes());p.write_text(json.dumps(check,indent=2));print('READY',root,flush=True)
  except Exception as e:print('GATE_ERROR',root,str(e),flush=True)
  finally:
   if session:session.stop()
 time.sleep(3)
