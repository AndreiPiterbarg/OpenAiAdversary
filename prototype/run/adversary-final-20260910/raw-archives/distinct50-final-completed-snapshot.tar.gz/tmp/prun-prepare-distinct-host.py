import pathlib,json,os,sys,subprocess,shutil,hashlib,concurrent.futures,dataclasses,time
os.environ.update(OPENBLAS_NUM_THREADS='1',OMP_NUM_THREADS='1',MKL_NUM_THREADS='1',PYTHONDONTWRITEBYTECODE='1')
sys.path.insert(0,'/tmp/prun-adversary-final-20260910/experiment-code-v8')
from domains.swe_agents.environment.interactive_runtime import InteractiveRuntime,HostRuntimePin,tree_digest
from domains.swe_agents.environment.guarded_session import install_host_guard
from domains.swe_agents.environment.prun_contract import parse_pytest_summary
H=pathlib.Path.home()/'va';R=pathlib.Path('/tmp/prun-distinct-host-prep-v3');R.mkdir(exist_ok=True)
selection=json.loads(pathlib.Path("/tmp/prun-adversary-final-20260910/distinct50-final/registration.json").read_text()); pins=[json.loads(pathlib.Path(row["remote_pin_path"]).read_text()) for row in selection["tasks"] if row["key"] not in ["django__asgiref-523","factoryboy__factory_boy-1067","stuartmaxwell__djpress-117"]]
(R/"selection.json").write_text(json.dumps({"rule":"userfixed50registration, exclude3alreadyready","keys":[p["key"] for p in pins]},indent=2))
env={'PATH':'/usr/bin:/bin','HOME':'/tmp','LANG':'C.UTF-8','GIT_CONFIG_NOSYSTEM':'1','GIT_CONFIG_GLOBAL':'/dev/null','GIT_AUTHOR_DATE':'2000-01-01T00:00:00Z','GIT_COMMITTER_DATE':'2000-01-01T00:00:00Z','PYTHONDONTWRITEBYTECODE':'1','OPENBLAS_NUM_THREADS':'1','OMP_NUM_THREADS':'1'}
def cmd(args,cwd=None):
 p=subprocess.run(args,cwd=cwd,env=env,capture_output=True,text=True,timeout=100)
 if p.returncode:raise RuntimeError('command failed '+str(args[:3])+': '+p.stderr[-400:])
 return p.stdout

def prep(pin):
 root=R/pin['key'];root.mkdir(exist_ok=True);start=time.time();session=None
 if (root/"extracted").exists():shutil.rmtree(root/"extracted")
 try:
  sha=hashlib.sha256()
  with open(pin['image'],'rb') as f:
   for b in iter(lambda:f.read(8*1024*1024),b''):sha.update(b)
  if sha.hexdigest()!=pin['image_sha256']:raise RuntimeError('image digest differs')
  cmd(['unsquashfs','-processors','1','-no-progress','-d',str(root/'extracted'),pin['image'],'usr/local',pin['workdir'].lstrip('/')])
  repo=root/'extracted'/pin['workdir'].lstrip('/');venv=root/'extracted/usr/local';cmd(['git','checkout','--detach',pin['commit']],repo)
  if cmd(['git','rev-parse','HEAD'],repo).strip()!=pin['commit']:raise RuntimeError('sourcecommit differs')
  if cmd(['git','status','--porcelain','--untracked-files=no'],repo).strip():raise RuntimeError('dirty pinnedsource')
  stage=cmd(['git','ls-files','--stage'],repo)
  if any(x.startswith(('120000','160000')) for x in stage.splitlines()):raise RuntimeError('tracked links/submodules require separate materialization policy')
  tracked=cmd(['git','ls-files','-z'],repo).split('\0');(root/'test.patch').write_text(pin['test_patch'])
  if pin['test_patch']:cmd(['git','apply',str(root/'test.patch')],repo)
  shutil.rmtree(repo/'.git')
  if any(x.name=='.git' for x in repo.rglob('.git')):raise RuntimeError('nestedgit')
  cmd(['git','init','-q'],repo);cmd(['git','add','--all'],repo);cmd(['git','-c','user.name=PRUN','-c','user.email=prun@invalid','commit','-qm','trusted prepared baseline'],repo)
  ref=cmd(['git','rev-parse','HEAD'],repo).strip()
  python=venv/'bin/python3';cmd([str(python),'-I','-B','-c','import pytest'])
  # Remove installed task copies: source must come solely from the pinned worktree.
  modules={x.split('/')[0] for x in tracked if x and '/' in x and (repo/x.split('/')[0]/'__init__.py').is_file()}
  for site in (venv/'lib').glob('python*/site-packages'):
   for module in modules:
    installed=site/module
    if installed.is_dir():shutil.rmtree(installed)
    elif installed.exists():installed.unlink()
   for p in site.glob('*.pth'):
    if '__editable__' in p.name or any(line.startswith('/') for line in p.read_text(errors='replace').splitlines()):p.unlink()
  (venv/'bin/pytest').write_text('#!'+str(python)+' -B\nimport sys,os\nsys.path[:0]=[os.getcwd(),os.path.join(os.getcwd(),"src")]\nimport pytest\nraise SystemExit(pytest.main())\n')
  (venv/'bin/pytest').chmod(0o755)
  links=[]
  for link in list(venv.rglob("*")):
   if not link.is_symlink():continue
   old=str(link.readlink());target=link.resolve()
   if old.startswith("/usr/local/"):target=venv/old[len("/usr/local/"):]
   if not target.is_relative_to(venv.resolve()) or not target.exists():raise RuntimeError("unrelocatable link "+str(link))
   links.append({"path":str(link.relative_to(venv)),"target":old,"materialized":str(target.relative_to(venv))})
   link.unlink()
   if target.is_dir():shutil.copytree(target,link)
   else:shutil.copy2(target,link)
  (root/"materialized-links.json").write_text(json.dumps(links,indent=2))
  hp=HostRuntimePin(task_key=pin['key'],commit=pin['commit'],repository=repo,repository_sha256=tree_digest(repo),venv=venv,venv_sha256=tree_digest(venv),system_python=pathlib.Path('/usr/bin/python3.12'))
  results={}
  for phase in ['baseline','gold']:
   runtime=InteractiveRuntime(hp);session=runtime.start_guarded(lambda raw,h:install_host_guard(raw,h,host_nproc=1536))
   if phase=='gold':
    path=session.scratch+'/gold.patch';session._raw.write_file(path,pin['gold_patch']);code,out,err=session.exec('git apply '+path,60)
    if code:raise RuntimeError('gold apply '+err[-400:])
   code,out,err=session.exec(pin['test_command'],100);runtime.verify();session.stop();session=None
   statuses=parse_pytest_summary(out,pin['fail_to_pass']+pin['pass_to_pass']);results[phase]={'exit':code,'stdout':out,'stderr':err,'statuses':statuses};(root/(phase+'.json')).write_text(json.dumps(results[phase],indent=2))
  valid=results['baseline']['exit']==1 and results['gold']['exit']==0 and all(results['baseline']['statuses'].get(x)=='FAILED' for x in pin['fail_to_pass']) and all(results['baseline']['statuses'].get(x)=='PASSED' for x in pin['pass_to_pass']) and all(results['gold']['statuses'].get(x)=='PASSED' for x in pin['fail_to_pass']+pin['pass_to_pass'])
  if not valid:raise RuntimeError('required baseline/gold transitions notverified')
  data={k:str(v) if isinstance(v,pathlib.Path) else v for k,v in dataclasses.asdict(hp).items()};data.update(prepared_frozen_tests=True,original_container_equivalence=False);(root/'host-runtime-pin.json').write_text(json.dumps(data,indent=2));(root/'original-pin.json').write_text(json.dumps(pin,indent=2));(root/'prepared-ref.txt').write_text(ref+'\n');(root/'baseline-untracked.json').write_text('{}\n');(root/'versions.txt').write_text(cmd([str(python),'-I','-B','-c','import sys,pytest; print(sys.version);print(pytest.__version__)']));(root/'compatibility-exact.json').write_text(json.dumps({'baseline_valid':True,'gold_valid':True,'prepared_ref':ref,'host_pin_sha256':hashlib.sha256((root/'host-runtime-pin.json').read_bytes()).hexdigest(),'single_commit_no_future_objects':True,'external_receipt_access_denied':False,'required_nodes':len(pin['fail_to_pass']+pin['pass_to_pass'])},indent=2));result={'status':'compatible','key':pin['key'],'path':str(root)}
 except Exception as e:result={'status':'not_ready','key':pin['key'],'error':str(e)}
 finally:
  if session:session.stop()
 result['seconds']=time.time()-start;(root/'preparation-result.json').write_text(json.dumps(result,indent=2));print(json.dumps(result),flush=True);return result
with concurrent.futures.ThreadPoolExecutor(max_workers=6) as pool:
 results=list(pool.map(prep,pins))
(R/'summary.json').write_text(json.dumps(results,indent=2))
